# Hooks for a Quest and Dialogue Layer

What a quest system could read and write **today**, without new plumbing, and
what it would need adding. Written so the narrative can be designed against the
real shape of the game rather than a guess at it.

---

## State a quest can already read

All of this is on `GameState` and is persisted:

| Field | Type | Use |
|---|---|---|
| `week`, `month`, `year` | number | Timing, deadlines, seasons |
| `money`, `renown`, `reputation`, `xp` | number | Stat gates |
| `vendorStanding` | `Record<buyerId, 0–100>` | Who trusts you |
| `contracts` | `Contract[]` | Live and settled promises |
| `unlockedVendorIds` | `string[]` | Who you have met (a latch) |
| `crew` | `CrewMember[]` | Named people, skills, tenure |
| `crewPool` | `CrewMember[]` | Who is looking for work |
| `recipeMastery` | `Record<recipeId, {level, cooks, bestScore, avgScore, recent}>` | What you can actually make |
| `analyzedRecipeIds`, `discoveredRecipeIds`, `unlockedRecipes` | `string[]` | What you know |
| `ownedBookIds` | `string[]` | What you have read |
| `logbook` | `LogEntry[]` | Every harvest, with a full run record |
| `inventory` | `Record<id, count>` | What is on the shelf |
| `customIngredients` | `Ingredient[]` | Your own koji and house strains |
| `ownedVessels` | `Record<vesselId, count>` | Capacity |
| `marketDemand` | `Record<FermentType, number>` | Glut state |
| `heat`, `undergroundBusts` | number | Underground exposure |
| `insolvencyStrikes` | number | How close to closing |
| `weather` | `WeatherState` | Season and conditions |

`logbook[].record` is the richest of these — every harvest keeps score, mass,
vessel, where it was pulled against its window, per-parameter drift, chamber
settings, enzymes, lineage and the post-mortem faults. A quest can ask *"have
they ever made a garum above 85 without going over 60 °C"* and get a real answer.

---

## Triggers that already fire

These are the moments a quest system could hang off, all in `App.tsx`:

- **Weekly boundary** (`newDay > 7`) — bills, demand recovery, standing decay,
  contract expiry, contract offers, crew advancement, pool refresh, vendor
  unlock latching. This is where a scheduler belongs.
- **Monthly** (`(newWeek - 1) % 4 === 0`) — crew pool rolls, weather shifts.
- **On sale** (`handleSell`) — buyer, price, score, standing delta.
- **On contract delivery** (`handleDeliver`) — units, completion.
- **On harvest** (`processHarvest`) — the full `LogEntry` is built here.
- **On sporulation** — lineage drift, new house strain minted.
- **On hire / let go** — crew changes.
- **On vendor unlock** (`newlyUnlockedVendors`) — already announces once.
- **On bankruptcy strike** and **game over**.

---

## The unlock system, which is the quest system's nearest relative

`VendorUnlock` in `types.ts` is a discriminated union and already supports six
kinds. A quest condition would want the same shape:

```ts
type VendorUnlock =
  | { kind: 'open' }
  | { kind: 'reputation'; value: number; label?: string }
  | { kind: 'renown'; value: number; label?: string }
  | { kind: 'ingredient'; ingredientId: string; label: string }
  | { kind: 'mastery'; recipeId: string; level: number; label: string }
  | { kind: 'recipeCount'; count: number; minScore: number; label: string }
  | { kind: 'introduction'; byBuyerId: string; standing: number; label: string };
```

`isVendorUnlocked()` evaluates these against `GameState`. A quest system could
reuse the evaluator directly, or generalise it into a `Condition` type that
quests and vendors both use — that is probably the right move.

**Not yet supported and explicitly asked for: `{ kind: 'randomEvent' }`.** There
is no event system to hang it on.

---

## Contracts are already quests, structurally

A `Contract` has: an issuer, a stated want, a measurable completion condition, a
deadline, a reward, a penalty, a status machine (`offered → active →
complete | failed | declined`), and a line of dialogue (`pitch`). A quest is the
same object with a richer condition and a narrative consequence instead of only
a cash one.

If the quest system generalises `Contract` rather than sitting beside it, the
order book UI, the delivery flow and the weekly expiry check all come for free.

---

## What would need building

1. **An event system.** A scheduler on the weekly boundary that can fire authored
   or random events, with a seeded RNG (the codebase deliberately avoids
   `Math.random()` in generators so results stay reproducible — `makeCandidate`
   and `makeContractOffer` both take a numeric seed instead).
2. **Story state on `GameState`.** Flags, quest instances, dialogue history.
   Note the three-place rule in `CLAUDE.md`: any new `GameState` field must be
   added to `types.ts`, the initial state literal in `App.tsx`, *and*
   `migrate()` in `services/persistence.ts`, or old saves load with `undefined`.
3. **A dialogue renderer.** Vendors currently have three fixed lines plus three
   warmth lines. There is no branching, no player choice, no memory of what was
   said.
4. **Era sequencing.** `ERAS` exists and tags recipes but nothing orders them
   into a campaign. This entangles with vendors — an era would plausibly gate
   which vendors exist at all.

---

## Writing notes

- Vendors should sound like their trade. A fence and a three-star chef do not
  share a register.
- Warmth lines are keyed to standing tier and are the cheapest way to make a
  relationship feel real: `cool` (0–14), `known` (15–59), `trusted` (60+).
- Seven vendors have no warmth lines yet: `bio_reclamation`, `food_blogger`,
  `mega_mart`, `bio_broker`, `collector`, `night_market`, `school_district`.
  Those are the obvious first writing task.
- Every line should carry information. The Sichuan chef refusing a paste teaches
  that doubanjiang wants mastery; the pharmacist's purchase order teaches that
  some buyers do not care about flavour at all.

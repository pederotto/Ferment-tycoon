# Known Bugs

Identified from screenshots on 2026-09-07. Not yet fixed — listed here so the
narrative work is not designed around behaviour that is about to change.

## 1. Reagent grams are applied per copy, not as a total  — SERIOUS

`components/BatchController.tsx` renders one slider per *ingredient type*, and
initialises it to the aggregate (`ing.mass × count`). But `customQuantities` is
keyed by ingredient id, and `calculateBatchDynamics` reduces over
`selectedIngredients`, which holds **one entry per unit**. So the slider value is
applied to every copy.

Observed: 28 units of anchovies with the slider at 46.85 kg produced a batch of
**1,311.8 kg** (28 × 46.85) and "OVERFLOWING BY 1251.80L".

It is only invisible while the slider is untouched, because the fallback
(`i.mass`, 1 kg) happens to be the correct per-copy value.

The "Fill to capacity at these proportions" button multiplies the same aggregate
and so compounds the error identically.

Fix direction: either divide by the unit count when writing `customQuantities`,
or stop storing per-type grams and store per-unit grams with the UI doing the
multiplication for display.

## 2. "What it became" renders an empty section in the harvest report

`components/HarvestReport.tsx` guards the section with `(enz || r.lineage)` but
then renders the enzyme line only `if (enz)` and the lineage line only if
`generation > 1`. A founder-culture batch with no enzymes recorded satisfies the
outer guard through `r.lineage` and then prints nothing under the heading.

Observed on Colatura di Alici: heading present, body empty.

## 3. "Approaching peak" shown at 3% progress

The ribbon in `BatchInspector` falls through to "Approaching Peak" for anything
below the peak window, so a batch at 3% of a window that opens at 90% is
described as approaching it. It needs a genuinely early state.

## 4. Salinity gauge reads as a warning when it is on target

Observed: salinity 25.0% against a target of 25%, drawn in the amber/warning
colour while temperature and humidity — also on target — are green. The
threshold logic for that dial is comparing against something other than the
recipe target.

## 5. Evenness barely moved on a 60 kg cask

The harvest report showed **98% evenness** on a 60 kg Colatura, capping the score
at 99. The model predicts a 60 L cask ending near 45 unattended. Two likely
causes, both worth checking: a liquid's low concentration makes `stiffness`
small, and a batch that completes in few ticks accumulates little decay. If a
60 kg liquid is genuinely meant to be almost immune, the mechanic is not doing
the job it was added for on exactly the vessels it was aimed at.

## 6. Quality 19/100 with an estimated payout of $495

Observed on a batch at 3% progress. Probably correct — an unfinished batch
scores badly and the payout scales with 60 kg of mass — but the pairing of one
star with a healthy price reads as a bug and is worth either fixing or
explaining in the UI.

# Ingredients

## Substrates

| Ingredient | Quality | Cost | Unit | Protein | Starch | Sugar | Fat | Salt | Wild |
|---|---|---|---|---|---|---|---|---|---|
| Pearl Barley | 60 | $5 | 1000g | 3 | 9 | 6 | 1 | 0 | 2 |
| Yellow Soybeans | 70 | $8 | 1000g | 9 | 2 | 3 | 4 | 0 | 3 |
| Black Soybeans | 85 | $15 | 1000g | 9 | 2 | 4 | 5 | 0 | 4 |
| Glutinous Rice | 75 | $12 | 1000g | 2 | 10 | 8 | 1 | 0 | 2 |
| Raw Milk | 80 | $25 | 1000ml | 6 | 0 | 5 | 8 | 1 | 8 |
| Fresh Anchovies | 90 | $40 | 1000g | 8 | 0 | 0 | 7 | 2 | 6 |
| Mackerel | 80 | $35 | 1000g | 8 | 0 | 0 | 9 | 1 | 5 |
| Mullet Roe Sack | 95 | $120 | 500g | 9 | 0 | 1 | 8 | 2 | 4 |
| Dried Scallops | 100 | $200 | 500g | 10 | 0 | 4 | 2 | 3 | 2 |
| Wild Ceps (Porcini) | 95 | $150 | 500g | 5 | 1 | 3 | 1 | 0 | 7 |
| Green Plums | 70 | $15 | 1000g | 1 | 1 | 6 | 0 | 0 | 5 |
| Yellow Peas | 60 | $8 | 1000g | 7 | 6 | 5 | 2 | 0 | 3 |
| Whole Garlic | 80 | $20 | 1000g | 4 | 3 | 7 | 1 | 0 | 4 |
| Broad Beans | 65 | $10 | 1000g | 8 | 6 | 4 | 2 | 0 | 3 |
| Krill / Shrimp Fry | 75 | $30 | 1000g | 9 | 0 | 1 | 4 | 3 | 8 |
| Coconut Sap | 80 | $25 | 1000ml | 1 | 0 | 10 | 2 | 0 | 6 |
| Young Pine Needles | 90 | $5 | 500g | 0 | 0 | 2 | 3 | 0 | 9 |
| Damask Rose Petals | 95 | $60 | 250g | 1 | 0 | 4 | 1 | 0 | 5 |
| Barley Koji | 80 | $25 | 1000g | 4 | 8 | 6 | 1 | 0 | 8 |
| Rice Koji | 80 | $30 | 1000g | 2 | 9 | 8 | 0 | 0 | 8 |
| Napa Cabbage | 72 | $6 | 1000kg | 1 | 1 | 4 | 0 | 0 | 7 |
| White Cabbage | 70 | $4 | 1000kg | 1 | 1 | 5 | 0 | 0 | 8 |
| Pork Belly | 84 | $55 | 1000kg | 7 | 0 | 0 | 9 | 1 | 3 |
| Baltic Herring | 76 | $22 | 1000kg | 8 | 0 | 0 | 8 | 2 | 6 |
| Skipjack Bonito | 92 | $48 | 1000kg | 12 | 0 | 0 | 1 | 1 | 3 |
| Black Tea | 80 | $9 | 1000ml | 0 | 0 | 2 | 0 | 0 | 1 |
| Heavy Cream | 82 | $18 | 1000ml | 3 | 0 | 4 | 10 | 0 | 4 |
| Toasted Hazelnuts | 88 | $42 | 1000kg | 6 | 1 | 3 | 9 | 0 | 2 |
| Egg Yolks | 86 | $24 | 500g | 8 | 0 | 1 | 9 | 1 | 2 |
| Pineapple (rind & core) | 70 | $8 | 1000kg | 1 | 1 | 9 | 0 | 0 | 8 |
| Cider Apples | 76 | $7 | 1000kg | 1 | 1 | 8 | 0 | 0 | 6 |
| Three-Year Soybeans | 96 | $34 | 1000kg | 11 | 1 | 1 | 6 | 0 | 3 |
| Bluefin Trim | 100 | $120 | 1000kg | 13 | 0 | 0 | 9 | 1 | 4 |
| Winter Black Trumpet | 94 | $68 | 1000kg | 8 | 1 | 2 | 1 | 0 | 7 |
| Fresh Anchovies (no papers) ⚠ | 60 | $19 | 1000g | 8 | 0 | 0 | 7 | 2 | 6 |
| Mackerel (no papers) ⚠ | 50 | $17 | 1000g | 8 | 0 | 0 | 9 | 1 | 5 |
| Raw Milk (no papers) ⚠ | 50 | $12 | 1000ml | 6 | 0 | 5 | 8 | 1 | 8 |
| Mullet Roe Sack (no papers) ⚠ | 65 | $58 | 500g | 9 | 0 | 1 | 8 | 2 | 4 |
| Dried Scallops (no papers) ⚠ | 70 | $96 | 500g | 10 | 0 | 4 | 2 | 3 | 2 |

## Starters & spores

| Ingredient | Quality | Cost | Strain bias | Notes |
|---|---|---|---|---|
| A. Oryzae Spores | 80 | $15 | 0.5 | Standard yellow koji-kin. Even-handed: makes both amylase and protease |
| Ancient Spores | 100 | $420 | 0.35 | Recovered from a clay pot 1000 years old. Protease-heavy and unpredict |
| Cheese Fly Larvae | 90 | $260 | — | Piophila casei. Illegal in most countries. |
| R. Oligosporus (Tempeh) | 88 | $35 | 0.45 | Binds cooked beans into a solid cake with white mycelium. Very little  |
| B. Subtilis var. natto | 86 | $30 | 0.2 | A bacterium, not a mould. Wants 40°C and wet air — conditions that wou |
| Nuruk Cake | 82 | $48 | 0.7 | A wild Korean starter cake: moulds, yeasts and bacteria together. Less |
| P. Roqueforti | 90 | $55 | 0.25 | Blue mould. Needs air in the paste to strike, which is why the cheese  |
| A. Glaucus (Katsuobushi) | 94 | $70 | 0.1 | Draws moisture out of dried fish over months of repeated sunning and m |
| SCOBY (Kombucha mother) | 84 | $28 | 0.5 | A cellulose raft of yeast and acetic bacteria. The yeast makes alcohol |
| Sake Koji-kin (Amylase strain) | 88 | $40 | 0.85 | Bred for saccharification. Run it warm and it will turn starch to suga |
| Shoyu Koji-kin (Protease strain) | 90 | $45 | 0.15 | Bred for proteolysis. Run it cool and it will free more glutamate than |
| A. Luchuensis (Black Koji) | 92 | $90 | 0.35 | Citric-acid producing black koji. Protease-leaning, and the acid prote |
| Heirloom Lacto Culture | 95 | $130 | — | A stable, vigorous LAB culture. Sours cleanly instead of wildly. |

## Additives & tools

| Ingredient | Type | Cost | Notes |
|---|---|---|---|
| Sea Salt | ADDITIVE | $2 | Basic NaCl. Prevents spoilage. |
| Trapani Sea Salt | ADDITIVE | $15 | Hand-harvested Sicilian salt. Rich in minerals. |
| Filtered Water | ADDITIVE | $1 | H2O. Essential for brine. |
| Cane Sugar | ADDITIVE | $5 | Food for yeast. |
| Dried Chilies | ADDITIVE | $12 | Adds heat and antibacterial properties. |
| Vial of Tears | ADDITIVE | $900 | Collected from the grieving. Saline and sorrowful. |
| Roasted Wheat | ADDITIVE | $5 | Essential for Shoyu. |
| Amino Sauce (Shoyu) | ADDITIVE | $40 | Pressed liquid savory seasoning. |
| Clip-on Fan | TOOL | $150 | Increases evaporation. Cools Koji. |
| Ultrasonic Mister | TOOL | $250 | Maintains high humidity. |
| Hydro-Press | TOOL | $500 | Extracts liquid from mash. Increases yield. |
| Centrifuge | TOOL | $2000 | Clarifies liquids by force. Removes solids. |
| Mash Paddle | TOOL | $180 | A long oak paddle. Reaches the bottom of a cask, so one pass actually turns the  |
| Geared Agitator | TOOL | $2400 | A motor and a slow paddle on a timer. Keeps a large vessel turning by itself — t |
| Rice Bran (Nuka) | ADDITIVE | $7 | The polishings. A bran bed lives for decades if you turn it by hand every day. |
| Hand-Harvested Flor de Sal | ADDITIVE | $26 | Raked off the surface by hand. Nothing in it but salt and the sea. |

## Suppliers

- **Nordic Staples Co.** (`nordic`) — Local grains, salts, and basic legumes.
- **Silk Road Imports** (`asia_import`) — Traditional soy, chilies, and rice varieties.
- **BioLab Cultures** (`biolab`) — Advanced spores and enzymatic starters.
- **Prime Sourcing Ltd.** (`prime`) — High-end meats and seasonal produce.
- **Lab Tech Solutions** (`tech`) — Heavy machinery and processing tools.
- **The Underground** (`black_market`) — Restricted, dangerous, and legendary items.
- **In-House Production** (`in_house`) — Made in your own lab.

# Vendor Profiles

Every buyer in the game, with every field that drives behaviour.
Generated from `constants.ts` — these are the live values, not a description of them.

## How a vendor works

- **priceMultiplier** scales the payout. The money formula is:
  `50 × recipe.difficulty × (score/50) × mass_kg^0.62 × priceMultiplier × standingBonus × chefBonus × marketDemand × ageBonus`
- **paysIn** is money or renown. Renown buyers pay no cash and do not sign contracts.
- **minScore** is the quality bar. Below `minScore - 25` they do not appear at all.
- **minReputation** gates the licensed ladder; a vendor with its own `unlock` uses that instead.
- **desiredTypes** is which ferment families they buy.
- **appetite** shapes contract size.
- **warmth** lines are keyed to standing tier and are the seed for dialogue.

## Standing tiers

| Standing | Tier | Price bonus | Meaning |
|---|---|---|---|
| 0+ | Unknown | +0% | They have no idea who you are. |
| 15+ | Noted | +5% | They recognise the name on the crate. |
| 35+ | Regular | +12% | You are on the list of people they call. |
| 60+ | Trusted | +22% | They will take your word on a batch they have not seen. |
| 85+ | Kitchen family | +35% | They plan menus around what you are making. |

---

## Metropolitan Culinary Co-op

`culinary_coop` · **Private**

> Local culinary network & craft fermentation exchange. Always buys honest ferments at fair market value.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1 |
| Min score | 10 |
| Min reputation | 0 |
| Buys | Lacto-Fermentation, Koji Cultivation, Miso/Paste, Shoyu/Sauce, Garum, Vinegar, Blackening, Alcoholic Brew |
| Contract appetite | 4 units |
| Unlock | `open` — {"kind":"open"} |

**Dialogue**

- *Intro:* “We distribute artisan and craft ferments across local restaurant kitchens.”
- *Accepts:* “Clean artisan batch accepted! Payment disbursed immediately.”
- *Refuses:* “Contaminated or unusable batch.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* They will take almost anything, and it shows.
- *Regular:* The buyer sets your crates aside from the rest.
- *Trusted/Family:* They ask you first when something is short.

---

## Bio-Organic Reclamation Co.

`bio_reclamation` · **Industry**

> Salvages spoiled, over-fermented, or contaminated cultures for enzymatic fertilizer compost.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×0.4 |
| Min score | 0 |
| Min reputation | 0 |
| Buys | Bio-Hazard, Lacto-Fermentation, Koji Cultivation, Miso/Paste, Shoyu/Sauce, Garum, Vinegar, Blackening, Alcoholic Brew |

**Dialogue**

- *Intro:* “We reclaim biological mass for nutrient compost and organic fertilizer.”
- *Accepts:* “Salvage verified. Biological haul compensation transferred.”
- *Refuses:* “Nothing to salvage.”

**Warmth by standing:** not yet written — a good place to start.

---

## Trending Eats

`food_blogger` · **Private**

> Influencer looking for content. Pays in Exposure (Renown).

| Field | Value |
|---|---|
| Pays in | renown |
| Price multiplier | ×1 |
| Min score | 50 |
| Min reputation | 0 |
| Buys | Lacto-Fermentation, Vinegar, Alcoholic Brew |

**Dialogue**

- *Intro:* “Can I film this for my story?”
- *Accepts:* “My followers love it!”
- *Refuses:* “Not photogenic enough.”

**Warmth by standing:** not yet written — a good place to start.

---

## SuperSave Market

`mega_mart` · **Supermarket**

> Requires high volume and safety. Low margins.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×0.8 |
| Min score | 40 |
| Min reputation | 0 |
| Buys | Lacto-Fermentation, Vinegar |

**Dialogue**

- *Intro:* “We need 500 units for aisle 4.”
- *Accepts:* “Adequate. Payment sent.”
- *Refuses:* “This is inconsistent. Rejected.”

**Warmth by standing:** not yet written — a good place to start.

---

## The Fermented Jar

`hipster_deli` · **Private**

> Boutique shop. Likes trendy, funky items.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1.5 |
| Min score | 60 |
| Min reputation | 10 |
| Buys | Miso/Paste, Koji Cultivation, Lacto-Fermentation |
| Contract appetite | 4 units |
| Unlock | `ingredient` — Buy black soybeans — they only stock what they cannot get elsewhere. |

**Dialogue**

- *Intro:* “Got anything... alive?”
- *Accepts:* “The microbes are singing!”
- *Refuses:* “Too commercial. Pass.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* They take your crate without looking up.
- *Regular:* The owner asks what you are working on next.
- *Trusted/Family:* Your name is chalked on the board behind the counter.

---

## L'Etoile du Nord

`fine_dining` · **Restaurant**

> 2-Star Michelin. Demands perfection and complexity.

| Field | Value |
|---|---|
| Pays in | renown |
| Price multiplier | ×2.5 |
| Min score | 85 |
| Min reputation | 50 |
| Buys | Garum, Shoyu/Sauce, Blackening |
| Contract appetite | 2 units |
| Unlock | `introduction` — Someone has to vouch for you. Get the deli to know you well first. |

**Dialogue**

- *Intro:* “Surprise my palate.”
- *Accepts:* “Exquisite. I will mention your name.”
- *Refuses:* “Pedestrian garbage.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* The pass is not the place for conversation.
- *Regular:* The chef de cuisine knows your name.
- *Trusted/Family:* You are walked through the kitchen, not left at the door.

---

## Han's Grill

`korean_bbq` · **Restaurant**

> High volume, traditional Korean flavors.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1.2 |
| Min score | 70 |
| Min reputation | 20 |
| Buys | Miso/Paste |
| Contract appetite | 4 units |

**Dialogue**

- *Intro:* “Need strong jang for the marinade.”
- *Accepts:* “Good depth. More next week.”
- *Refuses:* “Weak flavor.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* Handed over at the back door.
- *Regular:* The owner sits you down and feeds you.
- *Trusted/Family:* You are family, and family gets told the truth about a bad batch.

---

## Red Dragon Wok

`sichuan_house` · **Restaurant**

> Needs authentic, numbing fermentation.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1.4 |
| Min score | 75 |
| Min reputation | 25 |
| Buys | Miso/Paste |
| Contract appetite | 5 units |
| Unlock | `mastery` — Cook doubanjiang until you have the hang of it. The chef will not buy a paste from someone who has not. |

**Dialogue**

- *Intro:* “Is it authentic?”
- *Accepts:* “Perfect spice.”
- *Refuses:* “Lacks soul.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* The chef tastes it, says nothing, and pays.
- *Regular:* The chef starts telling you what was wrong with the last one.
- *Trusted/Family:* You are consulted before the menu changes.

---

## Zenith Pharma

`pharma` · **Industry**

> Buying enzymes and molds for extraction.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×2 |
| Min score | 80 |
| Min reputation | 30 |
| Buys | Koji Cultivation, Vinegar |
| Contract appetite | 6 units |
| Unlock | `renown` — Renown 40. They read about you before they call you. |

**Dialogue**

- *Intro:* “Purity is paramount.”
- *Accepts:* “Bio-availability is high. Proceed.”
- *Refuses:* “Contaminated.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* A purchase order and nothing else.
- *Regular:* The buyer starts asking technical questions.
- *Trusted/Family:* They send you their assay results unprompted.

---

## Vitrine & Sons

`bio_broker` · **Underground**

> Reclamation brokers. No questions about what died in there.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1 |
| Min score | 0 |
| Min reputation | 0 |
| Buys | Garum, Miso/Paste, Lacto-Fermentation, Shoyu/Sauce, Vinegar, Blackening, Koji Cultivation, Alcoholic Brew, Bio-Hazard |
| Underground tier | 1 |
| Fence | prices on funk/rot, ignores the critic score |
| Max safety | 55 (refuses anything safer) |
| Heat per sale | +8 |

**Dialogue**

- *Intro:* “Show us the ruined stock.”
- *Accepts:* “We can move that.”
- *Refuses:* “Too wholesome. Try a grocer.”

**Warmth by standing:** not yet written — a good place to start.

---

## The Curator

`collector` · **Underground**

> Buys dangerous or extinct flavors. Illegal.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×3.2 |
| Min score | 0 |
| Min reputation | 0 |
| Buys | Garum, Miso/Paste, Blackening, Bio-Hazard |
| Underground tier | 2 |
| Fence | prices on funk/rot, ignores the critic score |
| Requires | contraband sourcing |
| Heat per sale | +12 |

**Dialogue**

- *Intro:* “Do you have the forbidden sauce?”
- *Accepts:* “Thrillingly toxic.”
- *Refuses:* “Boringly safe.”

**Warmth by standing:** not yet written — a good place to start.

---

## The Night Market

`night_market` · **Underground**

> Cash, crates, no paperwork. Pays under the odds but never asks.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×0.9 |
| Min score | 25 |
| Min reputation | 0 |
| Buys | Lacto-Fermentation, Miso/Paste, Koji Cultivation, Shoyu/Sauce, Vinegar, Alcoholic Brew, Blackening, Garum |
| Underground tier | 2 |
| Heat per sale | +5 |

**Dialogue**

- *Intro:* “Cash tonight, no receipt.”
- *Accepts:* “Pleasure.”
- *Refuses:* “Not worth the crate.”

**Warmth by standing:** not yet written — a good place to start.

---

## The Alchemist Bar

`mixologist` · **Private**

> Experimental cocktail bar. Needs unique acids and umami.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1.8 |
| Min score | 65 |
| Min reputation | 15 |
| Buys | Alcoholic Brew, Vinegar, Garum |
| Contract appetite | 3 units |
| Unlock | `recipeCount` — Bring four different ferments to 70 or better. They want range, not one good trick. |

**Dialogue**

- *Intro:* “I need something to shock the senses.”
- *Accepts:* “This will make a phenomenal garnish.”
- *Refuses:* “Flat. Boring.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* A polite nod across the bar.
- *Regular:* They keep a bottle of yours behind the counter.
- *Trusted/Family:* Two drinks on the list are built around your work.

---

## City District Schools

`school_district` · **Industry**

> Bulk buying for cafeteria lunches. Low standards.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×0.6 |
| Min score | 30 |
| Min reputation | 5 |
| Buys | Miso/Paste |

**Dialogue**

- *Intro:* “We need 50kg of paste, doesn't need to be fancy.”
- *Accepts:* “Contract signed.”
- *Refuses:* “Too expensive or weird.”

**Warmth by standing:** not yet written — a good place to start.

---

## No-Moo Foods

`vegan_startup` · **Industry**

> Creating plant-based alternatives. Paying for clean labels.

| Field | Value |
|---|---|
| Pays in | money |
| Price multiplier | ×1.6 |
| Min score | 75 |
| Min reputation | 20 |
| Buys | Lacto-Fermentation, Miso/Paste |
| Contract appetite | 5 units |

**Dialogue**

- *Intro:* “Is it 100% plant-based and punchy?”
- *Accepts:* “Excellent umami profile.”
- *Refuses:* “Contains animal notes.”

**Warmth by standing** (the dialogue seed)

- *Unknown/Noted:* A courier collects it. You never meet anyone.
- *Regular:* Someone from product finally calls you directly.
- *Trusted/Family:* They want you on the packaging.

---


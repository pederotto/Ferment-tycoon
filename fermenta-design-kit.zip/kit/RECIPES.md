# Recipe Catalogue

45 named ferments, by family.

## Garum

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Colatura di Alici** `colatura` | 3 | 20° | 60% | 25% | 90–100% | 400s | Stir |
| **Garum Sociorum** `garum_sociorum` | 2 | 40° | 50% | 20% | 85–95% | 150s | Skim |
| **Nuoc Mam Nhi** `nuoc_mam` | 1 | 30° | 70% | 25% | 90–100% | 300s | Stir |
| **Rose Garum** `rose_garum` | 3 | 60° | 50% | 0% | 85–95% | 140s | Stir |
| **Lacryma (The Weeping)** `tears_garum` | 5 | 37° | 60% | 9% | 90–100% | 150s | Skim |
| **Surströmming** `surstromming` | 5 | 16° | 60% | 6% | 86–100% | 190s | Skim |

## Miso/Paste

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Cured Bottarga** `bottarga` | 2 | 15° | 30% | 15% | 90–100% | 60s | Flip |
| **Pixian Doubanjiang** `doubanjiang` | 3 | 22° | 60% | 12% | 85–95% | 160s | Stir |
| **Douchi (Black Beans)** `douchi` | 2 | 25° | 65% | 12% | 80–95% | 90s | Clean |
| **Gochujang** `gochujang` | 2 | 20° | 55% | 8% | 80–90% | 140s | Stir |
| **Hatcho Miso** `hatcho_miso` | 4 | 20° | 50% | 10% | 95–100% | 250s | Clean |
| **Shiro Miso** `shiro_miso` | 1 | 28° | 60% | 5% | 80–95% | 60s | Clean |
| **Bagoong Alamang** `bagoong` | 2 | 30° | 60% | 20% | 90–100% | 180s | Ventilate |
| **Pearl Barley Peaso** `yellow_peaso` | 1 | 20° | 55% | 6% | 80–95% | 90s | Clean |
| **Casu Marzu II** `casu_marzu` | 4 | 25° | 60% | 5% | 90–100% | 100s | Mix |
| **Doenjang** `doenjang` | 4 | 24° | 55% | 16% | 90–100% | 260s | Clean |
| **Katsuobushi** `katsuobushi` | 5 | 26° | 35% | 4% | 92–100% | 300s | Flip |
| **Cured Salumi** `salumi` | 4 | 13° | 75% | 3% | 90–100% | 220s | Flip |
| **Hazelnut Miso** `nut_miso` | 3 | 20° | 55% | 8% | 88–100% | 165s | Clean |
| **Shio-Tamago** `shio_tamago` | 3 | 6° | 55% | 10% | 88–100% | 90s | Clean |

## Lacto-Fermentation

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Ricotta Forte** `ricotta_forte` | 4 | 18° | 70% | 5% | 80–95% | 120s | Stir |
| **Lacto Porcini** `lacto_ceps` | 2 | 20° | 95% | 2% | 80–90% | 70s | Clean |
| **Nukazuke** `nukazuke` | 2 | 22° | 60% | 8% | 82–95% | 70s | Stir |
| **Sauerkraut** `sauerkraut` | 1 | 18° | 60% | 2% | 85–98% | 95s | Clean |
| **Kimchi** `kimchi` | 2 | 8° | 65% | 3% | 82–96% | 85s | Clean |
| **Blue Cheese** `blue_cheese` | 4 | 11° | 92% | 4% | 88–100% | 175s | Ventilate |
| **Cultured Cream** `cultured_butter` | 2 | 21° | 60% | 0% | 80–94% | 65s | Stir |
| **Aged Chili Mash** `chili_mash` | 3 | 22° | 60% | 9% | 88–100% | 210s | Stir |

## Alcoholic Brew

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Pine Needle Cheong** `cheong` | 1 | 20° | 50% | 0% | 80–95% | 100s | Ventilate |
| **Makgeolli** `makgeolli` | 3 | 25° | 60% | 0% | 80–94% | 110s | Stir |
| **Tepache** `tepache` | 1 | 26° | 60% | 0% | 76–90% | 60s | Ventilate |

## Vinegar

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Tuba Vinegar** `coconut_vin` | 2 | 28° | 70% | 0% | 85–95% | 150s | Stir |
| **Maesil Cheong** `maesil_cheong` | 2 | 20° | 55% | 0% | 86–100% | 145s | Clean |
| **Cider Vinegar** `cider_vinegar` | 3 | 24° | 65% | 0% | 84–100% | 175s | Ventilate |

## Blackening

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Scallop Fudge** `scallop_fudge` | 4 | 60° | 20% | 0% | 95–100% | 220s | Stir |
| **Black Apple** `black_apple` | 2 | 60° | 80% | 0% | 90–100% | 200s | Clean |
| **Black Garlic** `black_garlic` | 3 | 60° | 80% | 0% | 90–100% | 230s | Clean |

## Bio-Hazard

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Primordial Garum** `ancient_garum` | 5 | 30° | 80% | 15% | 95–100% | 200s | Flip |

## Koji Cultivation

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Barley Koji** `barley_koji` | 1 | 34° | 80% | 0% | 85–100% | 48s | Flip |
| **Shio Koji** `shio_koji` | 1 | 25° | 60% | 12% | 80–95% | 50s | Stir |
| **Amazake** `amazake` | 1 | 55° | 70% | 0% | 80–95% | 45s | Stir |
| **Tempeh** `tempeh` | 2 | 31° | 75% | 0% | 85–96% | 55s | Ventilate |
| **Nattō** `natto` | 3 | 40° | 95% | 0% | 88–100% | 50s | Ventilate |
| **Meju Block** `meju` | 4 | 22° | 65% | 0% | 88–100% | 120s | Flip |

## Kombucha

| Recipe | Diff | Temp | RH | Salt | Pull window | Duration | Intervention |
|---|---|---|---|---|---|---|---|
| **Kombucha** `kombucha` | 2 | 24° | 60% | 0% | 78–92% | 110s | Ventilate |


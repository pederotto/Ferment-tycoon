# Fermenta Tycoon — Design Kit

Generated 2026-09-07 from the live source, so every number here is what the game
actually runs, not a description of it.

## Read in this order

1. **GAME_SCOPE.md** — what the game is, the core loop, the systems, the
   economy in numbers, the tone, and where a story would attach.
2. **QUEST_HOOKS.md** — exactly what a quest and dialogue layer can read and
   write today, which triggers already fire, and what would need building.
3. **VENDORS.md** — all 15 buyer profiles with every field that drives
   behaviour, the standing tiers, and the dialogue that exists so far.
4. **CREW.md** — the four roles and the six traits.
5. **RECIPES.md** — the full catalogue by family, with parameters.
6. **INGREDIENTS.md** — substrates with their hidden stats, starters, additives,
   tools and suppliers.
7. **KNOWN_BUGS.md** — six issues found on 2026-09-07, unfixed. Worth reading
   before designing around current behaviour.

## Machine-readable

`vendors.json`, `recipes.json`, `crew.json`, `vessels.json`, `economy.json` and
`eras.json` are the same data as JSON, for generating or validating content
against.

## The one rule that will bite you

Any new `GameState` field must be added in **three** places or something breaks
silently:

1. `types.ts` — the interface
2. `App.tsx` — the initial state literal (miss it and a new game crashes)
3. `services/persistence.ts` — `migrate()` (miss it and every existing save
   loads with `undefined` in that field)

`CLAUDE.md` in the repo root has the rest of the invariants, all of them learned
by breaking them.

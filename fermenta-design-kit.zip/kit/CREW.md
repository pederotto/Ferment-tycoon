# The Crew

## Roles

### Lab Porter (`cleaner`)

Dedicated cleaning staff to maintain sterility.

- Base hiring cost: $300
- Base weekly wage: $100
- Effect: Hygiene never drops below 50%. Contamination risk reduced by 40%. Keeps large vessels a little more even.

### Lab Technician (`tech`)

Junior fermenter to monitor environmental controls.

- Base hiring cost: $800
- Base weekly wage: $250
- Effect: Corrects temperature drift in incubators, and walks the benches turning large vessels — halves how fast they stratify.

### Sous Chef (`chef`)

Culinary expert to refine flavor profiles.

- Base hiring cost: $2000
- Base weekly wage: $600
- Effect: Increases Sell Value by 15%. Extends "Peak Quality" window by 20%.

### Head of R&D (`rd`)

Master fermenter. A legend in the field.

- Base hiring cost: $5000
- Base weekly wage: $1200
- Effect: Prevents Thermal Death events. Maximizes Umami potential scaling.

## Traits

A hire's trait is what makes them good at one thing and awkward at another.
Skill (1–5) delivers more of a helpful trait and less of a harmful one.

| Trait | Upkeep | Hygiene | Quality | Wage | Character |
|---|---|---|---|---|---|
| **Methodical** | 0.7 | — | — | ×1.1 | Turns every vessel on a schedule and writes down when. Slow, but nothing stratifies on their watch. |
| **Meticulous** | — | 0.6 | — | ×1.15 | Sterilises things that were already sterile. Exhausting to work beside, and nothing ever gets infected. |
| **Green** | 1.2 | 1.15 | — | ×0.6 | Has read everything and done none of it. Cheap now, and will not be cheap for long. |
| **Good palate** | — | — | 1.08 | ×1.2 | Tastes a batch and tells you what it needs before the instruments agree. |
| **Tireless** | 0.62 | — | — | ×1.3 | Works the benches like they are being paid by the vessel. Which, in fairness, they nearly are. |
| **Stubborn** | 0.85 | 1.1 | 1.04 | ×0.9 | Has one way of doing things and it is usually right. Usually. |

*Upkeep below 1 means they slow stratification. Above 1 means they are clumsy.*

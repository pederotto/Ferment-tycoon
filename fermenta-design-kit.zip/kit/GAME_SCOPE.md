# Fermenta Tycoon — Scope and Context

A culinary fermentation tycoon sim. You run a small fermentation atelier: you buy
substrates, grow koji, make miso and garum and vinegar, and sell to people who
gradually come to know you. The pitch is that the simulation is *real* — the
mechanisms are the actual biochemistry, not a plausible-looking abstraction —
and the game is about learning to read them.

React 19 + TypeScript + Vite. No backend. Saves are versioned localStorage,
three slots, with a `migrate()` that forward-fills new fields.

---

## The core loop

1. **Draw reagents** at the Inoculation Bench — a substrate, usually a starter,
   salt and water titrated as percentages of the solids.
2. **Choose a vessel.** Capacity is the real constraint; a batch is worth
   `mass^0.62` so filling the vessel is always right, but volume brings its own
   problem (see *Evenness*).
3. **Set the chamber** — vent, mist, and on an incubator a heat setpoint.
4. **Seal it.** The recipe is *resolved* from what you put in, not chosen from a
   menu. `RECIPE_MATRIX` decides what the combination becomes.
5. **Hold it** while it runs. Temperature, humidity, stress, enzymes and
   evenness all move every tick. Interventions cost paused growth.
6. **Pull it in the window**, read the harvest report, sell it or keep it.
7. **Sell** to a vendor, deliver against a contract, keep it in the pantry as an
   ingredient, or lay it down to age.

A week is 7 in-game days at 8 seconds each — **56 seconds of wall clock**. Most
recipes run 60–400 seconds, so a ferment usually straddles more than one week.
That, not the batch price, is what governs income.

---

## What makes it a simulation rather than a timer

**Enzymes gate everything.** Protein is not umami until a protease cuts it up;
starch is not sweet until an amylase does; fat is not pungent until a lipase
does. Koji is not a product, it is the enzyme factory the rest runs on.

**You steer what the koji becomes.** Warm and wet grows amylase (sugar); cool
and dry grows protease (umami). The same spore makes either. This is the single
most important thing a new player has to learn.

**The substrate sets a ceiling, not a target.** A protein-rich fish can reach a
garum's umami; pearl barley cannot, however well you run it. Ingredient quality
raises the score cap (`60 + avgQuality × 0.4`).

**Salt and heat are alternative preservatives.** Above ~20% salt nothing
establishes at room temperature (the Roman route). Above ~55 °C nothing
establishes at any salinity (the modern route). Lowering *both* is the mistake.
This is the difference between Roman garum and the Noma method, and both are
playable.

**Volume ferments unevenly.** A 60 L cask has a warm core and a cool edge; salt
settles; the surface dries. `evenness` decays with volume and stiffness and
*caps* the score. Below ~3 L it does not decay at all, so the early game is
untouched. This is what makes scaling up demanding rather than free, and it is
why staff and machinery exist.

**Lineage is heritable.** Spores taken off a bed inherit the conditions that bed
was held at. Warm and damp selects for amylase, cool and dry for protease. After
a few generations you have a house strain nobody sells.

---

## Systems, and where they live

| System | File | What it does |
|---|---|---|
| Simulation core | `services/gameLogic.ts` | The tick, scoring, offers, overheads |
| Koji & enzymes | `services/koji.ts` | Enzyme development, lineage drift, pairing advice |
| Mastery | `services/mastery.ts` | Per-recipe XP, diagnosis, bench advice |
| Vendors | `services/vendors.ts` | Standing, contracts, unlock routes |
| Crew | `services/crew.ts` | Hiring pool, traits, skill growth |
| Persistence | `services/persistence.ts` | Versioned saves, 3 slots, `migrate()` |

---

## The economy, in numbers

- Starting money: **$1,800**
- Weekly floor: **$120 rent**, plus **$2 per litre** of bench past a 5 L free
  allowance (the starting jar and tray).
- Money for a batch:
  `50 × difficulty × (score/50) × mass_kg^0.62 × buyerMultiplier ×
   standingBonus × chefBonus × marketDemand × ageBonus`
- **Market saturation**: every loose sale cools demand for that ferment type by
  `0.06 × mass^0.62`, recovering `0.08` a week, floored at `0.25`.
  **Contracted goods do not cool the market at all** — that is the whole point
  of contracts.
- Three consecutive weeks in the red closes the lab.

Measured over 30 weeks with a full bench across four ferment types: the spread
between the best and worst vessel is about 1.3×, and the opening bench clears
the floor by roughly $40 a week. Scaling up is worth doing and is not the only
thing worth doing.

---

## Progression

There is no XP bar that makes you stronger. Progression is **information** and
**access**:

- **Mastery** (per recipe, "the Hand", 1–5) reveals target figures that show as
  `??` until earned. It never grants score — a score bonus would land before the
  terroir cap and let mastery substitute for buying good ingredients.
- **Books** teach recipes outright, and carry authored advice.
- **Reputation** opens the licensed buyer ladder.
- **Renown** is a second currency paid by prestige buyers.
- **Standing** is per-vendor and buys up to +35% on price.
- **Underground tier** derives from bench XP and opens fences.

---

## Tone

Warm artisan workshop, not a laboratory. Wood, clay, brass. The writing is dry
and specific and never exclaims. Nobody in this world says "Awesome!" — a chef
says *"I can tell you what it needs. Whether you listen is your business."*

Every piece of text should teach something true about fermentation, or reveal
something about a person. Ideally both.

---

## Where a story would attach

The game already has the pieces a narrative needs and does not yet use them:

- **Vendors are people** with standing, warmth lines and dialogue, and they ask
  you for things (contracts). A contract is already a small quest with a
  deadline and a consequence.
- **Crew are people** with names, traits and histories with you.
- **Eras** exist as data (`eras.json`) and tag recipes, but nothing sequences
  them into a campaign.
- **Eight vendors** carry warmth lines; the other seven do not yet.

What does not exist: an event system, branching dialogue, quest chains, or any
notion of story state. See `QUEST_HOOKS.md` for exactly what a quest layer could
read and write today without new plumbing.
